# VRSOperatorFlags
 Operator Flags for Virtual Radar Server
